JAS LAUNDRY ROOM — PHONE-ONLY CLOUD APK BUILD KIT v2.0

ഈ കിറ്റിൽ source.zip ആണ് യഥാർത്ഥ Android project source. GitHub Actions ഉപയോഗിച്ച് GitHub cloud-ൽ APK build ചെയ്യാനുള്ള workflow-യും ഉണ്ട്.
ഈ കിറ്റ് സ്വയം APK അല്ല. GitHub-ൽ workflow run വിജയിച്ചാൽ മാത്രമേ APK ലഭിക്കൂ.

ഫോണിൽ ചെയ്യേണ്ടത്:
1. ZIP ഫോണിൽ ഡൗൺലോഡ് ചെയ്ത് Files/ZArchiver ഉപയോഗിച്ച് Extract ചെയ്യുക.
2. https://github.com തുറന്ന് സൈൻ ഇൻ ചെയ്യുക; New repository ഉണ്ടാക്കുക (Private തിരഞ്ഞെടുക്കാം).
3. Repository-യിൽ Add file → Upload files തുറന്ന് കിറ്റിൽ നിന്നുള്ള source.zip മാത്രം upload ചെയ്ത് Commit changes ചെയ്യുക.
4. Add file → Create new file തിരഞ്ഞെടുക്കുക.
5. ഫയൽ പേര് കൃത്യമായി: .github/workflows/build-apk.yml
6. കിറ്റിൽ ഉള്ള അതേ പേരിലുള്ള workflow ഫയൽ തുറന്ന് മുഴുവൻ ഉള്ളടക്കം copy ചെയ്ത് GitHub editor-ൽ paste ചെയ്ത് Commit changes ചെയ്യുക.
7. Repository-യിലെ Actions tab തുറന്ന് “Build JAS Laundry Room APK” run തുറക്കുക.
8. Run പച്ച check ആയി വിജയിച്ചാൽ Artifacts-ൽ JAS-Laundry-Room-debug-APK download ചെയ്യുക.
9. Artifact ZIP extract ചെയ്ത് app-debug.apk കണ്ടെത്തുക.
10. Install ചെയ്യുക. Android ചോദിച്ചാൽ browser/file manager-ന് Install unknown apps permission നൽകേണ്ടി വരാം.

ഈ source-ൽ ചേർത്ത ഫീച്ചറുകൾ:
- WhatsApp Business-ലേക്ക് JPG bill share ചെയ്യാൻ native Android FileProvider bridge.
- Android 10+ ൽ Pictures/JAS Laundry Bills-ലേക്ക് JPG Gallery save.
- 80mm ESC/POS-compatible Bluetooth Classic SPP/RFCOMM printer തിരഞ്ഞെടുക്കാനുള്ള native dialog; receipt image/raster print.
- Bill-ൽ Remark / Special Instruction, Urgent Reminder Date.
- Reminders screen: delivery date-ന് ഒരു ദിവസം മുമ്പ്, urgent date, overdue orders; remarks കാണിക്കും.
- Android notification reminder ഏകദേശം രാവിലെ 9 മണിക്ക്; notification permission അനുവദിക്കണം.

പ്രധാന പരിധികളും സുരക്ഷയും:
- ഇവിടെ Android SDK/Gradle ഇല്ലാത്തതിനാൽ APK build ചെയ്തിട്ടില്ല. GitHub Actions build വിജയിക്കണം.
- WhatsApp Business, Gallery save, Bluetooth printer, notifications എന്നിവ യഥാർത്ഥ ഫോണിൽ end-to-end test ചെയ്തിട്ടില്ല. ഈ code source checks മാത്രമാണ് പാസായത്.
- Bluetooth direct printing സാധാരണ ESC/POS Bluetooth Classic SPP printer-കൾക്കായി ആണ്. BLE-only അല്ലെങ്കിൽ proprietary protocol printer പ്രവർത്തിക്കണമെന്നില്ല. ആദ്യം Android Settings-ൽ printer pair ചെയ്യണം.
- പുതിയ APK-യുടെ signing key പഴയ APK Maker build-ൽ നിന്നുള്ളതിൽ നിന്ന് വ്യത്യസ്തമായിരിക്കാം. Android update അനുവദിക്കാതിരുന്നാൽ uninstall ചെയ്യേണ്ടിവരാം; അതിന് മുമ്പ് JAS app-ൽ Settings & Backup → Download Backup ഉപയോഗിച്ച് data backup ചെയ്യുക. Uninstall ചെയ്താൽ app-ന്റെ local data നഷ്ടപ്പെടാം.
- APK build വിജയിക്കുന്നത് മാത്രം end-to-end പ്രവർത്തനം തെളിയിക്കുന്നില്ല. Install ചെയ്തശേഷം WhatsApp Business share, Gallery JPG, Bluetooth printer, reminders എന്നിവ പ്രത്യേകം പരീക്ഷിക്കുക.
