package com.jaslaundry.room

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.Context
import android.content.Intent
import android.content.ClipData
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.SystemClock
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.activity.ComponentActivity
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var pendingBluetoothReceipt: String? = null
    private val bluetoothPermissionRequest = 4812

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(this), "AndroidBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4813)
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == bluetoothPermissionRequest) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pendingBluetoothReceipt?.let { pending ->
                    if (pending.startsWith("__IMAGE__:")) showBluetoothPrinterPickerForImage(pending.removePrefix("__IMAGE__:"))
                    else showBluetoothPrinterPicker(pending)
                }
            } else {
                Toast.makeText(this, "Bluetooth permission is required to print to a paired printer.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun hasBluetoothConnectPermission(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun showBluetoothPrinterPicker(receipt: String) {
        try {
            val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter: BluetoothAdapter? = manager.adapter
            if (adapter == null) {
                Toast.makeText(this, "ഈ ഫോണിൽ Bluetooth ലഭ്യമല്ല.", Toast.LENGTH_LONG).show(); return
            }
            if (!adapter.isEnabled) {
                Toast.makeText(this, "ഫോണിന്റെ Bluetooth ON ചെയ്ത് വീണ്ടും ശ്രമിക്കുക.", Toast.LENGTH_LONG).show(); return
            }
            val devices = adapter.bondedDevices.toList().sortedBy { it.name ?: it.address }
            if (devices.isEmpty()) {
                Toast.makeText(this, "ആദ്യം Phone Settings → Bluetooth-ൽ 80mm printer pair ചെയ്യുക.", Toast.LENGTH_LONG).show(); return
            }
            val labels = devices.map { "${it.name ?: "Bluetooth Printer"} (${it.address})" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Choose 80mm Bluetooth Printer")
                .setItems(labels) { _, which -> sendReceiptToBluetooth(devices[which], receipt) }
                .setNegativeButton("Cancel", null)
                .show()
        } catch (e: SecurityException) {
            Toast.makeText(this, "Bluetooth permission was not granted.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Printer list failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showBluetoothPrinterPickerForImage(base64Png: String) {
        try {
            val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter = manager.adapter
            if (adapter == null) { Toast.makeText(this, "Bluetooth is not available on this phone.", Toast.LENGTH_LONG).show(); return }
            if (!adapter.isEnabled) { Toast.makeText(this, "Turn Bluetooth on and try again.", Toast.LENGTH_LONG).show(); return }
            val devices = adapter.bondedDevices.toList().sortedBy { it.name ?: it.address }
            if (devices.isEmpty()) { Toast.makeText(this, "Pair the 80mm printer in Android Bluetooth Settings first.", Toast.LENGTH_LONG).show(); return }
            val labels = devices.map { "${it.name ?: "Bluetooth Printer"} (${it.address})" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Choose 80mm Bluetooth Printer")
                .setItems(labels) { _, which -> sendImageReceiptToBluetooth(devices[which], base64Png) }
                .setNegativeButton("Cancel", null).show()
        } catch (e: Exception) { Toast.makeText(this, "Printer list failed: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun sendReceiptToBluetooth(device: BluetoothDevice, receipt: String) {
        Thread {
            var socket: android.bluetooth.BluetoothSocket? = null
            try {
                val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                socket = device.createRfcommSocketToServiceRecord(uuid)
                socket.connect()
                val out = socket.outputStream
                out.write(byteArrayOf(0x1B, 0x40)) // ESC @ initialize
                out.write(receipt.toByteArray(Charsets.UTF_8))
                out.write(byteArrayOf(0x0A, 0x0A, 0x0A))
                out.write(byteArrayOf(0x1D, 0x56, 0x01)) // partial cut where supported
                out.flush()
                runOnUiThread { Toast.makeText(this, "ബിൽ Bluetooth printer-ലേക്ക് അയച്ചു.", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Bluetooth print failed: ${e.message ?: "Check pairing and printer compatibility"}", Toast.LENGTH_LONG).show() }
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }.start()
    }

    private fun sendImageReceiptToBluetooth(device: BluetoothDevice, base64Png: String) {
        Thread {
            var socket: android.bluetooth.BluetoothSocket? = null
            try {
                val raw = Base64.decode(base64Png, Base64.DEFAULT)
                val original = BitmapFactory.decodeByteArray(raw, 0, raw.size) ?: throw IllegalStateException("Could not decode receipt image")
                val targetWidth = 576
                val bitmap = if (original.width == targetWidth) original else Bitmap.createScaledBitmap(original, targetWidth, (original.height.toFloat() * targetWidth / original.width).toInt().coerceAtLeast(1), true)
                val widthBytes = (bitmap.width + 7) / 8
                require(bitmap.height <= 65535) { "Receipt is too long for one raster print. Reduce remark length or split the bill." }
                val raster = ByteArray(widthBytes * bitmap.height)
                for (y in 0 until bitmap.height) {
                    for (x in 0 until bitmap.width) {
                        val pixel = bitmap.getPixel(x, y)
                        val luminance = (android.graphics.Color.red(pixel) * 299 + android.graphics.Color.green(pixel) * 587 + android.graphics.Color.blue(pixel) * 114) / 1000
                        if (luminance < 175) {
                            val index = y * widthBytes + x / 8
                            raster[index] = (raster[index].toInt() or (0x80 shr (x % 8))).toByte()
                        }
                    }
                }
                val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                socket = device.createRfcommSocketToServiceRecord(uuid)
                socket.connect()
                val out = socket.outputStream
                out.write(byteArrayOf(0x1B, 0x40))
                val header = byteArrayOf(0x1D, 0x76, 0x30, 0x00, (widthBytes and 0xFF).toByte(), ((widthBytes shr 8) and 0xFF).toByte(), (bitmap.height and 0xFF).toByte(), ((bitmap.height shr 8) and 0xFF).toByte())
                out.write(header)
                var offset = 0
                while (offset < raster.size) {
                    val count = minOf(4096, raster.size - offset)
                    out.write(raster, offset, count)
                    offset += count
                }
                out.write(byteArrayOf(0x0A, 0x0A, 0x0A))
                out.write(byteArrayOf(0x1D, 0x56, 0x01))
                out.flush()
                if (bitmap !== original) bitmap.recycle()
                original.recycle()
                runOnUiThread { Toast.makeText(this, "ബിൽ 80mm Bluetooth printer-ലേക്ക് അയച്ചു.", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Bluetooth print failed: ${e.message ?: "Check printer pairing and ESC/POS support"}", Toast.LENGTH_LONG).show() }
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }.start()
    }

    private fun cancelAlarm(requestId: Int) {
        try {
            val intent = Intent(this, ReminderReceiver::class.java)
            val pi = PendingIntent.getBroadcast(this, requestId, intent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            if (pi != null) {
                (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
                pi.cancel()
            }
        } catch (_: Exception) { }
    }

    private fun scheduleAlarm(title: String, body: String, date: String, requestId: Int) {
        if (date.isBlank()) return
        try {
            val format = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }
            val parsed = format.parse(date) ?: return
            val cal = Calendar.getInstance().apply { time = parsed; set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            if (cal.timeInMillis <= System.currentTimeMillis()) {
                val now = Calendar.getInstance()
                val sameDay = cal.get(Calendar.YEAR) == now.get(Calendar.YEAR) && cal.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
                if (sameDay) cal.timeInMillis = System.currentTimeMillis() + 60_000L else return
            }
            val intent = Intent(this, ReminderReceiver::class.java).apply {
                putExtra("title", title); putExtra("body", body)
            }
            val pi = PendingIntent.getBroadcast(this, requestId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        } catch (_: Exception) { }
    }

    inner class AndroidBridge(private val context: Context) {
        @JavascriptInterface
        fun saveImage(base64: String, filename: String) {
            runOnUiThread {
                var insertedUri: Uri? = null
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    require(bytes.size > 3 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() && bytes[2] == 0xFF.toByte()) {
                        "Invalid JPG image data"
                    }
                    val safeName = filename.replace(Regex("[^A-Za-z0-9._-]"), "_")
                        .let { if (it.endsWith(".jpg", ignoreCase = true)) it else "$it.jpg" }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val values = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, safeName)
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/JAS Laundry Bills")
                            put(MediaStore.Images.Media.IS_PENDING, 1)
                        }
                        insertedUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                            ?: throw IllegalStateException("Could not create image file")
                        contentResolver.openOutputStream(insertedUri!!)?.use { it.write(bytes) }
                            ?: throw IllegalStateException("Could not open image file for writing")
                        val published = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                        if (contentResolver.update(insertedUri!!, published, null, null) <= 0) {
                            throw IllegalStateException("Could not publish image file")
                        }
                        Toast.makeText(context, "JPG saved in Pictures/JAS Laundry Bills", Toast.LENGTH_LONG).show()
                    } else {
                        val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: filesDir
                        val targetDir = File(dir, "JAS Laundry Bills").apply {
                            if (!exists() && !mkdirs()) throw IllegalStateException("Could not create image folder")
                        }
                        FileOutputStream(File(targetDir, safeName)).use { it.write(bytes) }
                        Toast.makeText(context, "JPG saved in app Pictures storage", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    insertedUri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) {} }
                    Toast.makeText(context, "Bill JPG save failed: ${e.message ?: "Unknown error"}", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun shareImage(base64: String, filename: String, message: String) {
            runOnUiThread {
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    require(bytes.size > 3 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() && bytes[2] == 0xFF.toByte()) {
                        "Invalid JPG image data"
                    }
                    val safeName = filename.replace(Regex("[^A-Za-z0-9._-]"), "_")
                        .let { if (it.endsWith(".jpg", ignoreCase = true)) it else "$it.jpg" }

                    // Save a public Gallery copy on Android 10+.
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val values = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, safeName)
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/JAS Laundry Bills")
                            put(MediaStore.Images.Media.IS_PENDING, 1)
                        }
                        val galleryUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                            ?: throw IllegalStateException("Could not create Gallery image")
                        try {
                            contentResolver.openOutputStream(galleryUri)?.use { it.write(bytes) }
                                ?: throw IllegalStateException("Could not write Gallery image")
                            val published = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                            if (contentResolver.update(galleryUri, published, null, null) <= 0) {
                                throw IllegalStateException("Could not publish Gallery image")
                            }
                        } catch (e: Exception) {
                            contentResolver.delete(galleryUri, null, null)
                            throw e
                        }
                    }

                    // Share from a FileProvider URI. This is more compatible with WhatsApp
                    // than sharing a raw data URL or relying on a MediaStore URI alone.
                    val shareDir = File(cacheDir, "shared_bills").apply {
                        if (!exists() && !mkdirs()) throw IllegalStateException("Could not create share cache")
                    }
                    val shareFile = File(shareDir, safeName)
                    FileOutputStream(shareFile).use { it.write(bytes) }
                    val shareUri = FileProvider.getUriForFile(
                        this@MainActivity,
                        "$packageName.fileprovider",
                        shareFile
                    )
                    // Target WhatsApp Business specifically (package name: com.whatsapp.w4b).
                    // Launching the targeted ACTION_SEND opens its in-app recipient picker.
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "image/jpeg"
                        putExtra(Intent.EXTRA_STREAM, shareUri)
                        putExtra(Intent.EXTRA_TEXT, message)
                        clipData = ClipData.newUri(contentResolver, "Laundry bill JPG", shareUri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        setPackage("com.whatsapp.w4b")
                    }
                    startActivity(send)
                    Toast.makeText(context, "ബിൽ JPG WhatsApp Business-ൽ തുറന്നു. Contact തിരഞ്ഞെടുത്ത് Send അമർത്തുക.", Toast.LENGTH_LONG).show()
                } catch (e: android.content.ActivityNotFoundException) {
                    Toast.makeText(context, "WhatsApp Business ഇൻസ്റ്റാൾ ചെയ്തിട്ടുണ്ടോ എന്ന് പരിശോധിക്കുക. ശേഷം വീണ്ടും ശ്രമിക്കുക.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "WhatsApp Business share failed: ${e.message ?: "Unknown error"}", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun printBluetoothThermalImage(base64Png: String) {
            runOnUiThread {
                pendingBluetoothReceipt = "__IMAGE__:$base64Png"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasBluetoothConnectPermission()) {
                    requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), bluetoothPermissionRequest)
                } else {
                    showBluetoothPrinterPickerForImage(base64Png)
                }
            }
        }

        @JavascriptInterface
        fun printBluetoothThermal(receiptText: String) {
            runOnUiThread {
                pendingBluetoothReceipt = receiptText
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasBluetoothConnectPermission()) {
                    requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), bluetoothPermissionRequest)
                } else {
                    showBluetoothPrinterPicker(receiptText)
                }
            }
        }

        @JavascriptInterface
        fun scheduleReminder(billNo: String, customer: String, mobile: String, deliveryDate: String, urgentDate: String, remark: String, orderStatus: String) {
            runOnUiThread {
                val details = buildString {
                    append("Bill $billNo · $customer")
                    if (mobile.isNotBlank()) append(" · $mobile")
                    if (remark.isNotBlank()) append(" · $remark")
                }
                val baseId = (billNo + customer).hashCode() and 0x3fffffff
                cancelAlarm(baseId)
                cancelAlarm(baseId + 1)
                if (orderStatus.equals("Delivered", ignoreCase = true)) return@runOnUiThread
                if (deliveryDate.isNotBlank()) {
                    try {
                        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }
                        val d = fmt.parse(deliveryDate)
                        if (d != null) {
                            val c = Calendar.getInstance().apply { time = d; add(Calendar.DAY_OF_YEAR, -1) }
                            val reminderDate = fmt.format(c.time)
                            scheduleAlarm("Laundry delivery tomorrow", details, reminderDate, baseId)
                        }
                    } catch (_: Exception) { }
                }
                if (urgentDate.isNotBlank()) scheduleAlarm("Urgent laundry reminder", details, urgentDate, baseId + 1)
            }
        }

        @JavascriptInterface
        fun printThermal(html: String) {
            runOnUiThread {
                try {
                    val printView = WebView(this@MainActivity)
                    printView.settings.javaScriptEnabled = false
                    printView.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, url: String) {
                            val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                            val adapter = view.createPrintDocumentAdapter("JAS-Laundry-Thermal-Bill")
                            manager.print("JAS Laundry Thermal Bill", adapter,
                                PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize("JAS_80MM", "80 mm Thermal", 3150, 7874))
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build())
                        }
                    }
                    printView.loadDataWithBaseURL("https://appassets.androidplatform.net/", html, "text/html", "UTF-8", null)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Thermal print failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}
