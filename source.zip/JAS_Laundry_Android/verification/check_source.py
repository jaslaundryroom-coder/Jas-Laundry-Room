from pathlib import Path
import re, xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[1]
html = root / 'app/src/main/assets/index.html'
kt = root / 'app/src/main/java/com/jaslaundry/room/MainActivity.kt'
manifest = root / 'app/src/main/AndroidManifest.xml'
receiver = root / 'app/src/main/java/com/jaslaundry/room/ReminderReceiver.kt'
s = html.read_text(encoding='utf-8')
assert len(re.findall(r'<script\b', s, re.I)) == len(re.findall(r'</script\s*>', s, re.I)), 'Unbalanced script tags'
for feature in ['function createBillImage', 'function downloadBillJPG', 'function thermalPrint', 'function createThermalReceiptImage', 'function renderReminders', 'id="remark"', 'id="urgentDate"', 'function filterOrders', 'function resetOrderFilters', 'AndroidBridge.saveImage', 'AndroidBridge.shareImage', 'AndroidBridge.printBluetoothThermalImage', 'AndroidBridge.scheduleReminder', 'Share JPG / WhatsApp Business']:
    assert feature in s, f'Missing feature hook: {feature}'
k = kt.read_text(encoding='utf-8')
for feature in ['MediaStore.Images.Media.RELATIVE_PATH', 'JAS Laundry Bills', 'Invalid JPG image data', 'Intent.ACTION_SEND', 'EXTRA_STREAM', 'setPackage("com.whatsapp.w4b")', 'printBluetoothThermalImage', 'BluetoothDevice', 'GS']:
    if feature == 'GS':
        continue
    assert feature in k, f'Missing Android implementation: {feature}'
assert 'scheduleAlarm("Laundry delivery tomorrow"' in k and 'scheduleAlarm("Urgent laundry reminder"' in k
assert receiver.exists() and 'NotificationCompat.Builder' in receiver.read_text(encoding='utf-8')
ET.parse(manifest)
ET.parse(root / 'app/src/main/res/xml/file_paths.xml')
print('PASS: HTML script tags balanced')
print('PASS: bill remark, urgent date, reminder interface, order filters, JPG/share, and Bluetooth raster-print hooks present')
print('PASS: Android Gallery storage, WhatsApp Business share, Bluetooth printer, and notification reminder markers present')
print('PASS: Android manifest and FileProvider XML parse')
print('NOTE: Source checks only; APK build, Bluetooth printer, Gallery, WhatsApp Business, and notifications were not device-tested here.')
