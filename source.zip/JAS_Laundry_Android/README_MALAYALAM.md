# JAS Laundry Room — Android app project

ഈ ഫോൾഡറിൽ നിങ്ങളുടെ HTML ഫയൽ ഉൾപ്പെടുത്തിയ Android Studio WebView പ്രോജക്റ്റാണ്. ഇത് APK ആയി build ചെയ്യാൻ Android Studio ഉള്ള കമ്പ്യൂട്ടർ ആവശ്യമാണ്. ഈ പരിസരത്തിൽ Android SDK/Gradle build environment ലഭ്യമല്ലാത്തതിനാൽ ഇവിടെ നേരിട്ട് ഇൻസ്റ്റാൾ ചെയ്യാവുന്ന APK നിർമ്മിച്ച് പരിശോധിച്ചിട്ടില്ല.

## APK നിർമ്മിക്കുന്ന വിധം
1. കമ്പ്യൂട്ടറിൽ Android Studio ഇൻസ്റ്റാൾ ചെയ്യുക.
2. ഈ ZIP extract ചെയ്യുക.
3. Android Studio → **Open** → extract ചെയ്ത `JAS_Laundry_Android` ഫോൾഡർ തിരഞ്ഞെടുക്കുക.
4. Gradle sync പൂർത്തിയാകുന്നത് വരെ കാത്തിരിക്കുക; ആവശ്യപ്പെട്ടാൽ Android SDK Platform 35 ഇൻസ്റ്റാൾ ചെയ്യുക.
5. **Build → Build Bundle(s) / APK(s) → Build APK(s)** തിരഞ്ഞെടുക്കുക.
6. വിജയിച്ചാൽ APK സാധാരണയായി `app/build/outputs/apk/debug/app-debug.apk` എന്നിടത്ത് ഉണ്ടാകും.

## Firebase ശ്രദ്ധിക്കുക
- ഈ പ്രോജക്റ്റ് HTML-നെ Android WebView-ൽ തുറക്കുന്നു; Internet permission, JavaScript, DOM storage എന്നിവ സജ്ജമാക്കിയിട്ടുണ്ട്.
- Firebase യഥാർത്ഥ പ്രോജക്റ്റുമായി ബന്ധിപ്പിച്ച് പരിശോധിച്ചിട്ടില്ല. APK build വിജയിക്കുന്നത് Firebase login/sync വിജയിച്ചതായി അർത്ഥമല്ല.
- `https://appassets.androidplatform.net` origin ഉപയോഗിക്കുന്നതിനാൽ Firebase Authentication-ൽ `auth/unauthorized-domain` വന്നാൽ Firebase Console → Authentication → Settings → Authorized domains-ൽ ഈ domain ചേർക്കേണ്ടി വരാം. നിങ്ങളുടെ Firebase Console-ൽ അനുമതി ഉണ്ടെങ്കിൽ മാത്രം ഇത് ചെയ്യുക.
- Email/Password sign-in Firebase Console-ൽ enable ചെയ്തിരിക്കണം; Owner email-നുള്ള account നിലവിലുണ്ടായിരിക്കണം.

## പാക്കേജ് വിവരങ്ങൾ
- App label: JAS Laundry Room
- Application ID: `com.jaslaundry.room`
- Minimum Android: Android 6.0 (API 23)

## Add Item മാറ്റം
Price List-ലെ Add Item ഇനി browser prompt-കൾ ഉപയോഗിക്കുന്നില്ല. Category dropdown, Item Name, Regular Price, Student Offer Price എന്നിവയുള്ള ഫോമിലൂടെ പുതിയ ഐറ്റം ചേർക്കാം. Save Item അമർത്തുമ്പോൾ വിലകൾ നിലവിലെ local/cloud save flow വഴി സേവ് ചെയ്ത് Price List വീണ്ടും കാണിക്കും.

പരിശോധന കുറിപ്പ്: HTML-യിലെ inline JavaScript-ന് `node --check` syntax പരിശോധന വിജയിച്ചു. ഈ പരിതസ്ഥിതിയിൽ Android Gradle build അല്ലെങ്കിൽ യഥാർത്ഥ ഫോണിലെ APK പരിശോധന നടത്താൻ കഴിഞ്ഞിട്ടില്ല; ഇൻസ്റ്റാൾ ചെയ്ത APK പ്രവർത്തനക്ഷമമാണെന്ന് ഇതിലൂടെ ഉറപ്പിക്കുന്നില്ല.


## Bill JPG Gallery Save, WhatsApp Share & Thermal Print
- Bill / Order List-ൽ `Save JPG to Gallery` അമർത്തുമ്പോൾ JPG image സൃഷ്ടിച്ച് Android 10+ ൽ `Pictures/JAS Laundry Bills` എന്ന ഫോൾഡറിൽ save ചെയ്യും; Gallery/Photos-ൽ കാണാം.
- `Share JPG / WhatsApp Business` അമർത്തുമ്പോൾ ബിൽ JPG Gallery-യിൽ save ചെയ്ത് നേരിട്ട് WhatsApp Business (`com.whatsapp.w4b`) share screen തുറക്കാൻ ശ്രമിക്കും. Contact തിരഞ്ഞെടുക്കുക, പിന്നെ Send അമർത്തുക. ആപ്പ് സ്വയം recipient-നെ തിരഞ്ഞെടുക്കുകയോ Send അമർത്തുകയോ ചെയ്യില്ല.
- `Thermal Print` അമർത്തുമ്പോൾ Android system print dialog തുറക്കും. അവിടെ ലഭ്യമായ printer/print service തിരഞ്ഞെടുക്കുക; printer settings-ൽ 80 mm paper തിരഞ്ഞെടുക്കുക (printer 58 mm ആണെങ്കിൽ അതിന്റെ paper size തിരഞ്ഞെടുക്കുക). Printer/driver support വേണം. WhatsApp share-ും thermal print-ും വേറിട്ട പ്രവർത്തനങ്ങളാണ്; WhatsApp-ൽ നിന്ന് നേരിട്ട് print ചെയ്യുന്നത് printer/app support അനുസരിച്ചിരിക്കും.
- Gallery direct-save + native share implementation Android 10+ ൽ ഉദ്ദേശിച്ചിരിക്കുന്നു. Android SDK/build environment ലഭ്യമല്ലാത്തതിനാൽ APK build, physical phone Gallery, WhatsApp handoff, actual thermal printer എന്നിവ ഇവിടെ end-to-end പരീക്ഷിച്ചിട്ടില്ല.
- JavaScript syntax പരിശോധനയും ZIP integrity പരിശോധനയും വിജയിച്ചു. ഈ പരിതസ്ഥിതിയിൽ Android SDK/Gradle build ലഭ്യമല്ലാത്തതിനാൽ APK build/device printer test പൂർത്തിയാക്കിയിട്ടില്ല.


## WhatsApp sharing compatibility update (2026-10-25)
- Share JPG now writes the image to the public Gallery collection on Android 10+ and shares the image through an AndroidX FileProvider `content://` URI, with read permission granted to the receiving app. This avoids relying on a raw data URL and improves compatibility with WhatsApp/WhatsApp Business share targets.
- Added FileProvider configuration under `res/xml/file_paths.xml` and the AndroidX Core dependency.
- Source checks and XML parsing passed. This environment does not have Android SDK/Gradle available, so APK compilation and actual WhatsApp/Gallery/printer testing still need to be performed on a device.


## WhatsApp Business-specific targeting update (2026-10-25)
- Native share intent now targets package `com.whatsapp.w4b` specifically instead of showing a general Android chooser. If WhatsApp Business is missing or Android cannot open it, a clear toast message is shown.
- HTML button label now says `Share JPG / WhatsApp Business`.
- Static source checks and ZIP integrity should be rerun after edits. This is source code, not a built APK; no Android SDK/Gradle or physical device is available here, so end-to-end WhatsApp Business testing is not claimed.

## Update: WhatsApp Business, Gallery, 80mm Bluetooth Thermal Print, Reminders
- `Share JPG / WhatsApp Business` saves a JPG into the public Pictures/JAS Laundry Bills collection on Android 10+ and sends the image using a FileProvider URI targeted to WhatsApp Business (`com.whatsapp.w4b`). The user must choose a chat and press Send.
- `Save JPG to Gallery` writes the generated JPG to Pictures/JAS Laundry Bills on Android 10+.
- `Bluetooth Thermal Print` creates a receipt image at 576px width and opens a list of already-paired Bluetooth devices. Pair the 80mm ESC/POS-compatible printer in Android Settings first. This direct print path uses Bluetooth Classic SPP/RFCOMM; BLE-only printers and proprietary printer protocols may not work. Printer compatibility has not been confirmed without the user's exact printer model.
- New Bill/Edit Bill now has `Remark / Special Instruction` and `Urgent Reminder Date`. The Reminders page shows delivery reminders one day before the delivery date, urgent-date reminders, overdue orders, and remarks. Android notification reminders are scheduled for 9:00 AM; if a reminder date is today but 9:00 AM has passed, it is scheduled about one minute later. Android notification permission is requested on first launch.
- Existing bills are re-scheduled for notifications when a user opens the app. Marking a bill Delivered removes it from the in-app Reminders list, but notification scheduling can still require saving the edited bill again.
- Source-level JavaScript syntax checks, XML parsing, and ZIP integrity checks were run. No Android SDK/Gradle environment is installed in this workspace, so no APK build or physical device end-to-end test was performed. Do not treat these checks as proof that the user's specific phone, WhatsApp Business installation, or Bluetooth printer works.
